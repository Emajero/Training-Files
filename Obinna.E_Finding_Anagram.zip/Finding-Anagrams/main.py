# Check if two words are anagrams 
# Example:
# find_anagrams("hello", "check") --> False
# find_anagrams("below", "elbow") --> True


#from typing import Counter

word= input("Enter your first word: ")
anagram= input("Enter your second word: ")
sorted_word= sorted(word)
sorted_anagram= sorted(anagram)

if sorted_word == sorted_anagram:
    print("True")
else:
    print("False")





